package com.cardinal;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class PropertiesReader {
    Properties loadProperties() throws IOException {
        Properties properties = new Properties();
        try (InputStream input = getClass().getClassLoader().getResourceAsStream("./application.properties")) {
            properties.load(input);
            System.out.println("Properties loaded successfully!");
            return properties;
        } catch (IOException ex) {
            return null;
        }
    }
}
