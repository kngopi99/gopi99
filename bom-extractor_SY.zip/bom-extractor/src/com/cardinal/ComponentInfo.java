package com.cardinal;

import java.util.Objects;

public class ComponentInfo {
    private String componentNumber;
    private int level;

    public ComponentInfo(String componentNumber, int level) {
        this.componentNumber = componentNumber;
        this.level = level;
    }

    public String getComponentNumber() {
        return componentNumber;
    }

    public int getLevel() {
        return level;
    }

	@Override
	public int hashCode() {
		return Objects.hash(componentNumber, level);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ComponentInfo other = (ComponentInfo) obj;
		return Objects.equals(componentNumber, other.componentNumber) && level == other.level;
	}

	@Override
	public String toString() {
		return "ComponentInfo [componentNumber=" + componentNumber + ", level=" + level + "]";
	}
    
}
