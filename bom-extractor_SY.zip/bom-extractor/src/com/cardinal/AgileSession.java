package com.cardinal;

import com.agile.api.APIException;
import com.agile.api.AgileSessionFactory;
import com.agile.api.IAgileSession;

import java.io.IOException;
import java.util.HashMap;
import java.util.Properties;

public class AgileSession {
    private final Properties properties;

    public AgileSession() throws IOException {
        PropertiesReader propertiesReader = new PropertiesReader();
        properties = propertiesReader.loadProperties();
    }

    public IAgileSession getAgileSession() throws APIException {
        String userName=properties.getProperty("username");
        String password=properties.getProperty("password");
        String agileServerUrl=properties.getProperty("server_url");

        //TODO:: Need to remove once the code is validated.
        System.out.println("UserName :: "+userName);
        System.out.println("Password :: "+password);
        System.out.println("AgileServerUrl :: "+agileServerUrl);

        IAgileSession objAgileSession = null;
        //System.setProperty("disable.agile.sessionID.generation", "true");
        AgileSessionFactory factory = AgileSessionFactory.getInstance(agileServerUrl);
        HashMap<Integer, String> map = new HashMap<Integer, String>();
        map.put(AgileSessionFactory.USERNAME, userName);
        map.put(AgileSessionFactory.PASSWORD, password);
        objAgileSession = factory.createSession(map);
        return objAgileSession;
    }
    public void disconnect(IAgileSession objAgileSession) {
        if (objAgileSession != null) {
            objAgileSession.close();
        }

    }
}
