package com.cardinal;

import com.agile.api.*;
import java.io.*;
import java.util.*;

public class AgileServices {
	AgileSession agileSession;
	IAgileSession iAgileSession;

	public AgileServices() throws IOException, APIException {
		agileSession = new AgileSession();
		iAgileSession = agileSession.getAgileSession();
	}

	IItem getItem(String itemNumber) throws APIException {
		if (iAgileSession != null) {
			System.out.println("Agile Session :: " + iAgileSession.getCurrentUser());
		}
		if (itemNumber != null) {
			System.out.println("itemNumber :: " + itemNumber);
		}
		try {
			IItem item = (IItem) iAgileSession.getObject(IItem.OBJECT_TYPE, itemNumber);
			if(item != null)
			System.out.println("Retrieved Finished Good: " + item.getName());
			return item;
		} catch (APIException e) {
			e.printStackTrace();
			// System.out.println("Item not found: " + itemNumber);
			return null; // Handle the case where the item is not found
		}
	}
	
	public  Map<Integer, List<IItem>> fetchProductDetailsByLevel(IItem item, int level, Map<Integer, List<IItem>> levelMap) throws APIException {
        if (item == null) return null;

        ITable bomTable = item.getTable(ItemConstants.TABLE_BOM);
        System.out.println("Checking for  level" +level +  "for" + item.getName());
        
        List<IItem> itemList = new ArrayList<IItem>();
        if(levelMap.get(level) == null)
        {
        levelMap.put(level, itemList);
        }
        // Add the product to the respective level in the map
       
		 ITwoWayIterator bomItr = bomTable.getTableIterator();
		 while (bomItr.hasNext()) {
			 IRow bomRow = (IRow)bomItr.next();
			 IItem bomComponent = (IItem)bomRow.getReferent(); 
			 System.out.println("bom comp name" +bomComponent.getName());
			 List<IItem> itemListChild = levelMap.get(level);
			 itemListChild.add(bomComponent);
			 fetchProductDetailsByLevel(bomComponent, level + 1, levelMap);
			 
		 }
		 
		 return levelMap;

    }
	
	List<String> extractBOMDetailsToCSV(IItem item, List<String> headers) throws APIException, IOException {
		List<String> output = new ArrayList<String>();
		try {
			
			
			
			 Map<Integer, List<IItem>> inputMap = new HashMap<Integer, List<IItem>>();
			
			 Map<Integer, List<IItem>> levelMap = fetchProductDetailsByLevel(item,1,inputMap);
			 
			 if(levelMap == null)
			 {
				 return output;
			 }
			
			 TreeMap<Integer, List<IItem>> sortedMap = new TreeMap<>(levelMap);
			 
			  
			 
			 for (Map.Entry<Integer, List<IItem>> entry : sortedMap.entrySet()) {
		            System.out.println("Key: " + entry.getKey() + ", Value: " + entry.getValue());
		            
		            List<IItem> items =  entry.getValue();
		            for(IItem item1 : items)
		            {
		            	 System.out.println("processing for"+ item1.getName());
		            	 StringBuffer sb = new StringBuffer();
		            	 sb.append(item1.getName()+ ",");
		            	 sb.append(entry.getKey().toString()+ ",");
		            	 List<String> values = new ArrayList<>();
				    	 values.add(item1.getName());
				    	 values.add(entry.getKey().toString());
		            ITable bomTable1 = item1.getTable(ItemConstants.TABLE_BOM);
		           // System.out.println("entered the row for item" +item1.getName());
				   // Iterator<?> bomIterator1 = bomTable1.iterator();
		            ITwoWayIterator bomIterator1 = bomTable1.getTableIterator();
				    while(bomIterator1.hasNext())
				    {
				    	
				    IRow row = (IRow) bomIterator1.next();
				   // System.out.println("found row for " +item1.getName() + "with name" + row.getName());
				    
				    for(String header : headers)
				    {
				    	ICell cellValue = row.getCell(header);
				    	if(cellValue != null )
				    	{
				    	 System.out.println("value pulled for header"+ header + "is" +  cellValue.toString());
				    	 Object cellVal =  cellValue.getValue();
				    	 if(cellVal == null || cellVal.toString() == null)
				    	 {
				    	 values.add("empty");
				    	 sb.append("empty"+ ",");
				    	 }
				    	 else
				    	 {
				    		 values.add(cellVal.toString());
				    		 sb.append(cellVal.toString()+ ",");
				    	 }
				    	}
				    	
				    	else 
				    	{
				    		 System.out.println("value pulled for header"+ header + "is empty");
				    		 values.add("empty");
				    		 sb.append("empty"+ ",");
				    	}
				    	//values.add(cellValue != null ? cellValue.toString() : "empty");
				    }
				    
				  /*  ICell[] cellarr =  row.getCells();
				    for(int i = 0; i< cellarr.length;i++)
				    {
				    	ICell icell = cellarr[i];
				    	String cellname = icell.getName();
				    	ICell cellValue =  row.getCell(cellname);
				    	System.out.println("cell name"+ cellname);
				    	System.out.println("cell value"+ row.getCell(cellname));
				    	values.add(cellValue != null ? cellValue.toString() : "");
				    } */
				    
				    // Collect values of each column
		        
		// Write BOM details (all columns) to CSV
				   
		           // System.out.println("output name"+ output);
		           // csvWriter.append("\n");
				    }
				    String valuesforCsv = String.join(",", values);
				    System.out.println("csv row "+ sb.toString());
		            output.add(sb.toString());
		            }
		        }
			 
			// csvWriter.flush();
				//csvWriter.close();
			} catch (APIException e) {
				e.printStackTrace();

			} catch (Exception e) {
				e.printStackTrace();

			}
		
		  System.out.println("output size"+ output.size());
		
		return output;
				
	
	}
	
	
}
