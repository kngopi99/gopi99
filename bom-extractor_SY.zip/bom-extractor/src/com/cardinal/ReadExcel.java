package com.cardinal;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;

public class ReadExcel {
    // Method to read component numbers and levels from Excel
    static List<ComponentInfo> readComponentDetailsFromExcel(String excelFilePath) {
        List<ComponentInfo> componentInfoList = new ArrayList<>();

        try (FileInputStream fis = new FileInputStream(new File(excelFilePath));
             Workbook workbook = new XSSFWorkbook(fis)) {

            Sheet sheet = workbook.getSheetAt(0);  // Assume data is in the first sheet
            for (Row row : sheet) {
                if (row.getRowNum() == 0) {
                    // Skip header row
                    continue;
                }

                String componentNumber = row.getCell(0).getStringCellValue();
                int level =0;
                try{
                    level = (int) row.getCell(2).getNumericCellValue();
                }
                catch(Exception ex){
                    level = 0;
                }
                componentInfoList.add(new ComponentInfo(componentNumber, level));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return componentInfoList;
    }
}
