package com.cardinal;

import com.agile.api.APIException;
import com.agile.api.IItem;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.cardinal.ReadExcel.readComponentDetailsFromExcel;

public class DriverClass {

    public static void main(String[] args) throws IOException, APIException {
        File directory = new File("./output");
        if (!directory.exists()) {
            System.out.println("Folder Created :: " + directory.mkdir());
        }
        List<ComponentInfo> componentInfoList = readComponentDetailsFromExcel("./input.xlsx");
        System.out.println("List Size :: "+componentInfoList.size());
        System.out.println(componentInfoList);
        System.out.println("Excel Load Step Done");
        AgileServices agileServices = new AgileServices();
        
    	List<String> output = new ArrayList<String>();

        for (ComponentInfo componentInfo : componentInfoList) {
            String componentNumber = componentInfo.getComponentNumber();
            int level = componentInfo.getLevel();

            boolean headersWritten = false;

            IItem finishedGoodItem = agileServices.getItem(componentInfo.getComponentNumber());
            
            FileWriter csvWriter = new FileWriter("./output/" + componentNumber + ".csv");
            
            List<String> csvheaders = Arrays.asList("Item Number","Level","BOM.Attachments (Image)","BOM.Manufacturer (Image)","BOM.Pending Changes (Image)","BOM.Pending Declarations (Image)",
            		"BOM.Item Description","BOM.Item Rev","BOM.Qty","BOM.Find Num","BOM.Ref Des","BOM.Sites","BOM.BOM Notes",
            		"BOM.Summary Compliance","BOM.Subclass","BOM.Component Effective From","BOM.Component Discontinue Date","BOM.Item Lifecycle Phase",
            		"BOM.Alternate FG Part(s)","BOM.Alternate Part(s)","BOM.Alternate Document(s)","BOM.OP#","BOM.Planned?","BOM.Scrap Factor","BOM.Stocking Unit of Measure",
            		"BOM.Device Contact Location","BOM.Device Contact Duration (Cumulative Sum)","BOM.Primary Contact Qualifier","BOM.Secondary Contact Qualifier",
            		"BOM.EUMDR","BOM.EUMDR Substances","BOM.Cal Prop 65","BOM.Cal Prop 65 Substances","BOM.REACH Auth","BOM.REACH Auth Substances","BOM.REACH Candidate",
            		"BOM.REACH Candidate Substances","BOM.Additional Subs of Concern","BOM.Additional Subst of Concern Substances","BOM.RoHS3","BOM.RoHS3 Substances","BOM.Animal Sources","BOM.Animal Sources Substances",
            		"BOM.PFAS","BOM.PFAS Substances","BOM.Allergens","BOM.Allergens Substances","BOM.Human Sources","BOM.Human Sources Substances");
            
            List<String> headers = Arrays.asList("BOM.Attachments (Image)","BOM.Manufacturer (Image)","BOM.Pending Changes (Image)","BOM.Pending Declarations (Image)",
            		"BOM.Item Description","BOM.Item Rev","BOM.Qty","BOM.Find Num","BOM.Ref Des","BOM.Sites","BOM.BOM Notes",
            		"BOM.Summary Compliance","BOM.Subclass","BOM.Component Effective From","BOM.Component Discontinue Date","BOM.Item Lifecycle Phase",
            		"BOM.Alternate FG Part(s)","BOM.Alternate Part(s)","BOM.Alternate Document(s)","BOM.OP#","BOM.Planned?","BOM.Scrap Factor","BOM.Stocking Unit of Measure",
            		"BOM.Device Contact Location","BOM.Device Contact Duration (Cumulative Sum)","BOM.Primary Contact Qualifier","BOM.Secondary Contact Qualifier",
            		"BOM.EUMDR","BOM.EUMDR Substances","BOM.Cal Prop 65","BOM.Cal Prop 65 Substances","BOM.REACH Auth","BOM.REACH Auth Substances","BOM.REACH Candidate",
            		"BOM.REACH Candidate Substances","BOM.Additional Subs of Concern","BOM.Additional Subst of Concern Substances","BOM.RoHS3","BOM.RoHS3 Substances","BOM.Animal Sources","BOM.Animal Sources Substances",
            		"BOM.PFAS","BOM.PFAS Substances","BOM.Allergens","BOM.Allergens Substances","BOM.Human Sources","BOM.Human Sources Substances");
            
            List<String> csvList = new ArrayList<String>();
            String header = String.join(",", csvheaders);
            csvList.add(header);
           List<String> values= agileServices.extractBOMDetailsToCSV(finishedGoodItem, headers);
           System.out.println("final length" + values.size());
           csvList.addAll(values);
                 
          for(String value : csvList)
          {
        	 // System.out.println("row in csv" + value);
        	  csvWriter.write(value);
        	  csvWriter.write("\n");
          }
          csvWriter.flush();
          csvWriter.close();
           

        }

    }
}
